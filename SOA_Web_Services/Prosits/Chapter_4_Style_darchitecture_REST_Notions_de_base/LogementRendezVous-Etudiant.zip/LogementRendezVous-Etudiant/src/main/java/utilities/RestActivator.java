package utilities;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


public class RestActivator{
}
